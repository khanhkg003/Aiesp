package com.fakelag.vpn;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class FakeLagVpnService extends VpnService implements Runnable {
    private Thread vpnThread;
    private ParcelFileDescriptor vpnInterface = null;

    @Override
    public void onCreate() {
        super.onCreate();
        Builder builder = new Builder();
        builder.setSession("FakeLagVPN");
        builder.addAddress("10.0.0.2", 32);
        builder.addRoute("0.0.0.0", 0); // Bắt toàn bộ IPv4
        
        // Cấu hình DNS
        builder.addDnsServer("8.8.8.8");

        vpnInterface = builder.establish();
        if (vpnInterface != null) {
            vpnThread = new Thread(this, "VpnThread");
            vpnThread.start();
        }
    }

    @Override
    public void run() {
        try {
            FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
            FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
            ByteBuffer packet = ByteBuffer.allocate(32767);

            while (!Thread.interrupted()) {
                int length = in.read(packet.array());
                if (length > 0) {
                    // Phân tích IP Header (20 bytes) để tìm Protocol
                    // byte thứ 9 là Protocol (17 = UDP, 6 = TCP)
                    int protocol = packet.get(9) & 0xFF;
                    
                    // Nếu là UDP (Free Fire game traffic), tạo độ trễ
                    if (protocol == 17) {
                        try {
                            Thread.sleep(MainActivity.LAG_MS);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    // Ghi gói tin ra ngoài (chuyển tiếp)
                    packet.limit(length);
                    out.write(packet.array(), 0, length);
                    packet.clear();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        try {
            if (vpnInterface != null) vpnInterface.close();
            if (vpnThread != null) vpnThread.interrupt();
        } catch (Exception e) {}
        super.onDestroy();
    }
}
