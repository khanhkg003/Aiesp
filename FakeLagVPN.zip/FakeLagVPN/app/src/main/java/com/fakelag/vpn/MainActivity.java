package com.fakelag.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static int LAG_MS = 200; // Độ trễ mặc định (ms)
    private TextView tvLag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        tvLag = new TextView(this);
        tvLag.setText("Độ trễ (Lag): " + LAG_MS + " ms");
        layout.addView(tvLag);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(1000); // Max 1 giây
        seekBar.setProgress(LAG_MS);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                LAG_MS = progress;
                tvLag.setText("Độ trễ (Lag): " + LAG_MS + " ms");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        layout.addView(seekBar);

        Button btnStart = new Button(this);
        btnStart.setText("BẬT FAKE LAG & ANTIBAN");
        btnStart.setOnClickListener(v -> {
            Intent intent = VpnService.prepare(MainActivity.this);
            if (intent != null) {
                startActivityForResult(intent, 0);
            } else {
                onActivityResult(0, RESULT_OK, null);
            }
        });
        layout.addView(btnStart);

        Button btnStop = new Button(this);
        btnStop.setText("TẮT VPN");
        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, FakeLagVpnService.class));
            Toast.makeText(this, "Đã tắt VPN", Toast.LENGTH_SHORT).show();
        });
        layout.addView(btnStop);

        setContentView(layout);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result == RESULT_OK) {
            Intent intent = new Intent(this, FakeLagVpnService.class);
            startService(intent);
            Toast.makeText(this, "Đã bật Fake Lag", Toast.LENGTH_SHORT).show();
        }
    }
}
