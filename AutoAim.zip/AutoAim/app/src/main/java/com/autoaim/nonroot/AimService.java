package com.autoaim.nonroot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.WindowManager;
import org.tensorflow.lite.Interpreter;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class AimService extends Service {
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private Interpreter tflite;
    private long lastAimTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            tflite = new Interpreter(loadModelFile("detect.tflite"));
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String channelId = "aim_channel";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(channelId, "AI Aim", NotificationManager.IMPORTANCE_LOW));
        }
        Notification notification = new Notification.Builder(this, channelId)
                .setContentTitle("AI Aim Running").setSmallIcon(android.R.drawable.ic_menu_camera).build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, notification);

        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (manager != null && data != null) {
            mediaProjection = manager.getMediaProjection(resultCode, data);
            startCapture();
        }
        return START_STICKY;
    }

    private void startCapture() {
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay("AimCapture", width, height, getResources().getDisplayMetrics().densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, null);

        imageReader.setOnImageAvailableListener(reader -> {
            Image image = reader.acquireLatestImage();
            if (image != null) {
                Bitmap bitmap = ImageToBitmap(image);
                image.close();
                if (bitmap != null && System.currentTimeMillis() - lastAimTime > 1000) { // Delay 1s chống spam
                    detectAndAim(bitmap);
                }
            }
        }, new Handler(Looper.getMainLooper()));
    }

    private void detectAndAim(Bitmap bitmap) {
        if (tflite == null || AimAccessibility.getInstance() == null) return;

        Bitmap resized = Bitmap.createScaledBitmap(bitmap, 320, 320, true);
        ByteBuffer input = ByteBuffer.allocateDirect(320 * 320 * 3 * 4).order(ByteOrder.nativeOrder());
        for (int y = 0; y < 320; y++) {
            for (int x = 0; x < 320; x++) {
                int pixel = resized.getPixel(x, y);
                input.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
                input.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
                input.putFloat((pixel & 0xFF) / 255.0f);
            }
        }

        float[][][] output = new float[1][6300][85];
        tflite.run(input, output);

        float screenCenterX = bitmap.getWidth() / 2f;
        float screenCenterY = bitmap.getHeight() / 2f;
        float minDist = 300f; // Bán kính tìm kiếm

        float targetX = -1, targetY = -1;
        float closest = minDist;

        for (int i = 0; i < 6300; i++) {
            float conf = output[0][i][4];
            if (conf > 0.5f) {
                float x = output[0][i][0] * bitmap.getWidth();
                float y = output[0][i][1] * bitmap.getHeight();
                float dist = (float) Math.hypot(x - screenCenterX, y - screenCenterY);
                if (dist < closest) {
                    closest = dist;
                    targetX = x; targetY = y;
                }
            }
        }

        if (targetX != -1 && targetY != -1) {
            // Vuốt từ tâm ra mục tiêu
            AimAccessibility.getInstance().snapToTarget(screenCenterX, screenCenterY, targetX, targetY);
            lastAimTime = System.currentTimeMillis();
        }
    }

    private Bitmap ImageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        Bitmap bitmap = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        return Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());
    }

    private MappedByteBuffer loadModelFile(String modelPath) throws Exception {
        FileInputStream inputStream = new FileInputStream(getAssets().openFd(modelPath).getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, getAssets().openFd(modelPath).getStartOffset(), getAssets().openFd(modelPath).getDeclaredLength());
    }

    @Override public void onDestroy() {
        super.onDestroy();
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) mediaProjection.stop();
        if (tflite != null) tflite.close();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
