package com.autoaim.nonroot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class AimAccessibility extends AccessibilityService {
    private static AimAccessibility instance;
    public static AimAccessibility getInstance() { return instance; }

    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    public void snapToTarget(float startX, float startY, float targetX, float targetY) {
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(targetX, targetY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 30)); // 30ms
        dispatchGesture(builder.build(), null, null);
    }
}
