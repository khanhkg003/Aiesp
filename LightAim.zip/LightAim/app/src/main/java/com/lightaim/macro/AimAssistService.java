package com.lightaim.macro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.view.accessibility.AccessibilityEvent;

public class AimAssistService extends AccessibilityService {
    private WindowManager windowManager;
    private Button aimButton;
    
    // CẤU HÌNH ĐỘ NHẠY: Số pixel vuốt lên (Tăng số này nếu muốn kéo mạnh hơn, giảm nếu muốn nhẹ hơn)
    private final int SWIPE_UP_DISTANCE = 80; 
    
    // CẤU HÌNH THỜI GIAN: Thời gian vuốt tính bằng ms (Giảm số này để vuốt nhanh hơn)
    private final int SWIPE_DURATION_MS = 15;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Tạo nút bấm nổi (Floating Button)
        aimButton = new Button(this);
        aimButton.setText("AIM");
        aimButton.setAlpha(0.6f); // Độ mờ của nút (0.0 - 1.0)
        aimButton.setOnClickListener(v -> performSwipeUp());

        // Cấu hình WindowManager cho nút nổi
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        // Vị trí nút trên màn hình (Bạn có thể kéo nút này đi chỗ khác khi chạy)
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 150; 
        params.y = 600; 

        windowManager.addView(aimButton, params);
    }

    private void performSwipeUp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int screenHeight = getResources().getDisplayMetrics().heightPixels;

            // Tính toán điểm bắt đầu và kết thúc ở giữa màn hình
            float centerX = screenWidth / 2f;
            float centerY = screenHeight / 2f;
            float endY = centerY - SWIPE_UP_DISTANCE;

            Path swipePath = new Path();
            swipePath.moveTo(centerX, centerY);
            swipePath.lineTo(centerX, endY); // Vuốt thẳng lên trên

            GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
            // Thực hiện vuốt
            gestureBuilder.addStroke(new GestureDescription.StrokeDescription(swipePath, 0, SWIPE_DURATION_MS)); 

            dispatchGesture(gestureBuilder.build(), null, null);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (aimButton != null) {
            windowManager.removeView(aimButton);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {}
}
