package com.lightaim.macro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);

        // Nút 1: Yêu cầu quyền Overlay (Vẽ nút bấm nổi)
        Button btnOverlay = new Button(this);
        btnOverlay.setText("1. Cấp quyền hiển thị (Overlay)");
        btnOverlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(this, "Đã có quyền Overlay", Toast.LENGTH_SHORT).show();
            }
        });
        layout.addView(btnOverlay);

        // Nút 2: Mở cài đặt Trợ năng (Bắt buộc để giả lập vuốt)
        Button btnAccessibility = new Button(this);
        btnAccessibility.setText("2. Bật Trợ năng (Accessibility)");
        btnAccessibility.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(this, "Tìm Light Aim và bật lên", Toast.LENGTH_LONG).show();
        });
        layout.addView(btnAccessibility);

        setContentView(layout);
    }
}
