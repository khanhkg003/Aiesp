package com.yourpackage.aiesp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class OverlayView extends View {
    private final Paint paint;
    private final List<RectBox> boxes = new ArrayList<>();

    public OverlayView(Context context) {
        super(context);
        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f);
    }

    public void addBox(float left, float top, float right, float bottom) {
        boxes.add(new RectBox(left, top, right, bottom));
    }

    public void clearBoxes() {
        boxes.clear();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (RectBox box : boxes) {
            canvas.drawRect(box.left, box.top, box.right, box.bottom, paint);
        }
    }

    static class RectBox {
        float left, top, right, bottom;
        RectBox(float l, float t, float r, float b) { left = l; top = t; right = r; bottom = b; }
    }
}
